/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldAlert, Landmark, Scale, FileText, ArrowLeft, 
  HelpCircle, Sparkles, ShieldCheck, GraduationCap, Building2, 
  BookOpen, Clock, Activity, MessageSquare, ArrowUpRight, Megaphone,
  ChevronRight, ChevronLeft, Calendar, Volume2, Shield, PhoneCall, Check, Link,
  Compass, Newspaper, ZoomIn, ZoomOut, RotateCcw
} from 'lucide-react';

import Header from './components/Header';
import Footer from './components/Footer';
import NewsTicker from './components/NewsTicker';
import AboutSection from './components/AboutSection';
import MediaCenter from './components/MediaCenter';
import ContactSection from './components/ContactSection';
import CitizenGuide from './components/CitizenGuide';
import ComplaintsSection from './components/ComplaintsSection';
import AdminPanel from './components/AdminPanel';
import NewsDetail from './components/NewsDetail';

import { newsArticles as staticNewsArticles, staticStats } from './data/staticData';
import { NewsArticle } from './types';
import { 
  ResponsiveContainer, AreaChart, Area, BarChart, Bar, XAxis, YAxis, 
  CartesianGrid, Tooltip, Legend, PieChart, Pie, Cell 
} from 'recharts';

const THEMES: Record<string, { primary: string; primaryLight: string; gold: string; goldLight: string }> = {
  navy: {
    primary: '#0a1931',
    primaryLight: '#15305b',
    gold: '#d4af37',
    goldLight: '#e6c260',
  },
  green: {
    primary: '#064e3b',
    primaryLight: '#0f766e',
    gold: '#eab308',
    goldLight: '#fef08a',
  },
  maroon: {
    primary: '#500724',
    primaryLight: '#701a75',
    gold: '#d97706',
    goldLight: '#fcd34d',
  },
  stone: {
    primary: '#1e293b',
    primaryLight: '#334155',
    gold: '#f59e0b',
    goldLight: '#fde047',
  }
};

const chartGrowthData = [
  { year: '2020', cases: 1800, toxicology: 4200 },
  { year: '2021', cases: 2500, toxicology: 6800 },
  { year: '2022', cases: 3900, toxicology: 11500 },
  { year: '2023', cases: 5400, toxicology: 16300 },
  { year: '2024', cases: 7200, toxicology: 22000 },
  { year: '2025', cases: 11300, toxicology: 29500 },
  { year: '2026', cases: 14800, toxicology: 35000 },
];

const chartDistributionData = [
  { name: 'فحوصات جنائية واعتداءات', value: 45, count: 6660, color: '#102544' },
  { name: 'استشارات طبية شرعية', value: 25, count: 3700, color: '#f59e0b' },
  { name: 'تشريح ووفيات جنائية', value: 15, count: 2220, color: '#ef4444' },
  { name: 'تحاليل السموم والكيمياء', value: 15, count: 2220, color: '#10b981' },
];

const chartMonthlyData2026 = [
  { month: 'يناير', cases: 950, toxicology: 2200 },
  { month: 'فبراير', cases: 1100, toxicology: 2450 },
  { month: 'مارس', cases: 1250, toxicology: 2800 },
  { month: 'أبريل', cases: 1050, toxicology: 2300 },
  { month: 'مايو', cases: 1350, toxicology: 3100 },
  { month: 'يونيو', cases: 1500, toxicology: 3400 },
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white/95 border border-gray-250 p-3 rounded-lg shadow-md text-right text-xs select-none">
        <p className="font-bold text-gray-900 mb-1">{label}</p>
        {payload.map((pld: any, index: number) => (
          <p key={`tooltip-item-${pld.dataKey || pld.name || index}`} style={{ color: pld.color || pld.fill }} className="font-bold flex items-center justify-end gap-1.5 mt-1">
            <span>{pld.value.toLocaleString('en-US')}</span>
            <span>{pld.name}:</span>
          </p>
        ))}
      </div>
    );
  }
  return null;
};

const CustomPieTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-white/95 border border-gray-250 p-3 rounded-lg shadow-md text-right text-xs select-none">
        <p className="font-bold text-gray-900 mb-1">{data.name}</p>
        <p className="font-bold text-[#102544] flex items-center justify-end gap-1.5 mt-1">
          <span>{data.value}% ({data.count.toLocaleString('en-US')} حالة)</span>
          <span>النسبة والمجموع:</span>
        </p>
      </div>
    );
  }
  return null;
};

const CountUp = ({ value }: { value: string }) => {
  const [count, setCount] = useState(0);
  const [hasStarted, setHasStarted] = useState(false);
  const elementRef = React.useRef<HTMLSpanElement>(null);

  const isPercent = value.includes('%');
  const hasPlus = value.includes('+');
  const isFloat = value.includes('.');
  const numericString = value.replace(/[^0-9.]/g, '');
  const endValue = parseFloat(numericString) || 0;

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setHasStarted(true);
        }
      },
      { threshold: 0.1 }
    );
    if (elementRef.current) {
      observer.observe(elementRef.current);
    }
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!hasStarted) return;
    let startTimestamp: number | null = null;
    const duration = 1500; // 1.5 seconds

    const step = (timestamp: number) => {
      if (!startTimestamp) startTimestamp = timestamp;
      const progress = Math.min((timestamp - startTimestamp) / duration, 1);
      
      let currentVal = progress * endValue;
      if (!isFloat) {
        currentVal = Math.floor(currentVal);
      } else {
        currentVal = Math.round(currentVal * 10) / 10;
      }
      
      setCount(currentVal);
      if (progress < 1) {
        window.requestAnimationFrame(step);
      } else {
        setCount(endValue);
      }
    };
    window.requestAnimationFrame(step);
  }, [hasStarted, endValue, isFloat]);

  const displayValue = isFloat ? count.toFixed(1) : Math.floor(count).toLocaleString('en-US');

  return (
    <span ref={elementRef}>
      {hasPlus && '+'}
      {displayValue}
      {isPercent && '%'}
    </span>
  );
};

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [activeArticle, setActiveArticle] = useState<NewsArticle | null>(null);
  const [copied, setCopied] = useState(false);
  const [newsTextSize, setNewsTextSize] = useState<number>(15);
  const [previousTab, setPreviousTab] = useState<string>('home');

  const handleViewArticle = (article: NewsArticle) => {
    setActiveArticle(article);
    setPreviousTab(currentTab === 'news-detail' ? 'media' : currentTab);
    setCurrentTab('news-detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCopyLink = (article: NewsArticle) => {
    const shareUrl = `${window.location.origin}?article=${article.id}`;
    navigator.clipboard.writeText(shareUrl).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  // Dynamic news list loaded from localStorage (or falling back to static list)
  const [newsList, setNewsList] = useState<any[]>(staticNewsArticles);
  const [settingsVersion, setSettingsVersion] = useState(0);

  // Dynamic customization states
  const [stats, setStats] = useState<any[]>(staticStats);
  const [centerMainTitle, setCenterMainTitle] = useState('المرجع الوطني المعتمد للخبرة الطبية الشرعية والنفسية والأدلة الجنائية');
  const [centerMainDesc, setCenterMainDesc] = useState('أهلاً بكم في البوابة الرقمية للمركز الوطني للطب الشرعي، التابع لوزارة العدل بالجمهورية اليمنية. نوفر التقارير والتحاليل الطبية الشرعية والجنائية وفحوصات السموم والمخدرات بأحدث المعايير العلمية والموثوقية المطلقة.');
  const [centerMainBadge, setCenterMainBadge] = useState('لدعم تحقيق العدالة وحماية الحقوق');
  const [themeName, setThemeName] = useState('navy');
  const [sectionsOrder, setSectionsOrder] = useState<string[]>(['news', 'audiences', 'stats', 'charts']);

  const scrollToSection = (id: string) => {
    if (currentTab !== 'home') {
      setCurrentTab('home');
      setTimeout(() => {
        const element = document.getElementById(id);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 350);
    } else {
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }
  };

  // Home Page News Slider & Mini News index state
  const [mainNewsIndex, setMainNewsIndex] = useState(0);
  const [sideNewsIndex, setSideNewsIndex] = useState(0);
  const [countdown, setCountdown] = useState(10); // Countdown for 10s side news

  // Load news and seed defaults if empty, and support deep linking of shared articles
  useEffect(() => {
    let currentNews = staticNewsArticles;
    const storedNews = localStorage.getItem('forensic_news');
    if (storedNews) {
      try {
        currentNews = JSON.parse(storedNews);
        setNewsList(currentNews);
      } catch (err) {
        setNewsList(staticNewsArticles);
      }
    } else {
      localStorage.setItem('forensic_news', JSON.stringify(staticNewsArticles));
      setNewsList(staticNewsArticles);
    }

    // Check URL params for a shared news article ID on mount
    const params = new URLSearchParams(window.location.search);
    const articleId = params.get('article');
    if (articleId) {
      const found = currentNews.find((n: any) => n.id === articleId);
      if (found) {
        setActiveArticle(found);
        setCurrentTab('news-detail');
      }
    }

    // Load other custom settings dynamically
    const savedStats = localStorage.getItem('forensic_stats');
    if (savedStats) {
      try {
        setStats(JSON.parse(savedStats));
      } catch (e) {
        setStats(staticStats);
      }
    } else {
      setStats(staticStats);
    }

    const savedTitle = localStorage.getItem('setting_center_main_title') || 'المرجع الوطني المعتمد للخبرة الطبية الشرعية والنفسية والأدلة الجنائية';
    const savedDesc = localStorage.getItem('setting_center_main_desc') || 'أهلاً بكم في البوابة الرقمية للمركز الوطني للطب الشرعي، التابع لوزارة العدل بالجمهورية اليمنية. نوفر التقارير والتحاليل الطبية الشرعية والجنائية وفحوصات السموم والمخدرات بأحدث المعايير العلمية والموثوقية المطلقة.';
    const savedBadge = localStorage.getItem('setting_center_main_badge') || 'لدعم تحقيق العدالة وحماية الحقوق';
    setCenterMainTitle(savedTitle);
    setCenterMainDesc(savedDesc);
    setCenterMainBadge(savedBadge);

    const savedTheme = localStorage.getItem('setting_color_theme') || 'navy';
    setThemeName(savedTheme);

    const savedOrder = localStorage.getItem('setting_sections_order');
    if (savedOrder) {
      try {
        const parsed = JSON.parse(savedOrder);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setSectionsOrder(parsed);
        } else {
          setSectionsOrder(['news', 'audiences', 'stats', 'charts']);
        }
      } catch (e) {
        setSectionsOrder(['news', 'audiences', 'stats', 'charts']);
      }
    } else {
      setSectionsOrder(['news', 'audiences', 'stats', 'charts']);
    }
  }, [settingsVersion]);

  // Main news auto-slide every 5 seconds
  useEffect(() => {
    if (newsList.length <= 1) return;
    const interval = setInterval(() => {
      setMainNewsIndex((prev) => (prev + 1) % newsList.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [newsList.length]);

  // Side news auto-slide every 10 seconds, with an updated countdown progress
  useEffect(() => {
    if (newsList.length <= 1) return;
    
    // Reset countdown when sideNewsIndex changes
    setCountdown(10);

    const interval = setInterval(() => {
      setSideNewsIndex((prev) => (prev + 1) % newsList.length);
    }, 10000);

    const countdownInterval = setInterval(() => {
      setCountdown((prev) => (prev > 1 ? prev - 1 : 10));
    }, 1000);

    return () => {
      clearInterval(interval);
      clearInterval(countdownInterval);
    };
  }, [newsList.length, sideNewsIndex]);

  const getSourceBadgeColor = (source: string) => {
    return source === 'المركز' 
      ? 'bg-[#1a365d]/10 text-[#1a365d] border-[#1a365d]/25' 
      : 'bg-[#9d174d]/10 text-[#9d174d] border-[#9d174d]/25';
  };

  const renderNewsSection = () => {
    return (
      <section id="news-highlights" className="scroll-mt-48 bg-gradient-to-b from-[#102544] to-[#1a365d] text-white py-12 border-b-4 border-amber-500 select-none">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Title and Intro */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end mb-8 pb-3 border-b border-white/10">
            <div className="text-right">
              <span className="text-amber-400 text-xs font-bold tracking-widest uppercase bg-white/10 px-3 py-1.5 rounded-full border border-amber-400/20 inline-block mb-2">
                التحديث الإخباري الفوري بالتعاون مع وزارة العدل
              </span>
              <h3 className="text-xl sm:text-3xl font-extrabold text-white">
                البث الإخباري والمركز الإعلامي المشترك
              </h3>
              <p className="text-xs text-white/70 mt-1 font-medium">عرض متحرك ومصور لأهم أخبار الطب الشرعي الجنائي والبيانات العدلية المباشرة</p>
            </div>

            <button 
              onClick={() => setCurrentTab('media')}
              className="text-xs font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1 transition-colors mt-3 sm:mt-0"
            >
              <span>تصفح الأرشيف الإعلامي الكامل</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>

          {/* Dual Grid: Slider + 10s Side Panel */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
            
            {/* Column 1: Main Moving News Slider with Images (8 cols / 2/3 width) */}
            <div className="lg:col-span-8 bg-white rounded-2xl border border-gray-200/50 shadow-md overflow-hidden flex flex-col justify-between min-h-[420px] relative group text-gray-800">
              
              {/* Active news article slide content */}
              {newsList.length > 0 ? (
                <div className="flex flex-col h-full justify-between">
                  
                  {/* Upper visual: Image with text overlay */}
                  <div className="relative h-60 w-full overflow-hidden shrink-0">
                    <img 
                      src={newsList[mainNewsIndex]?.image || 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=800'} 
                      alt={newsList[mainNewsIndex]?.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
                    />
                    {/* Overlay gradient */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent"></div>
                    
                    {/* Overlay tag & Date */}
                    <div className="absolute top-4 right-4 flex items-center gap-2">
                      <span className="bg-amber-500 text-white font-extrabold text-[10px] px-2.5 py-1 rounded-md shadow-sm">
                        {newsList[mainNewsIndex]?.category || 'أخبار'}
                      </span>
                      <span className="bg-white/10 backdrop-blur-md text-white/90 text-[10px] font-mono px-2 py-1 rounded-md font-bold">
                        {newsList[mainNewsIndex]?.date}
                      </span>
                    </div>
                    
                    {/* Title on image overlay */}
                    <div className="absolute bottom-4 right-4 left-4 text-right">
                      <h4 
                        onClick={() => handleViewArticle(newsList[mainNewsIndex])}
                        className="text-white font-bold text-sm sm:text-lg leading-snug hover:text-amber-400 cursor-pointer line-clamp-2"
                      >
                        {newsList[mainNewsIndex]?.title}
                      </h4>
                    </div>
                  </div>

                  {/* Bottom textual part */}
                  <div className="p-6 flex-grow flex flex-col justify-between text-right">
                    <p className="text-xs sm:text-sm text-gray-500 leading-relaxed line-clamp-3 mb-6">
                      {newsList[mainNewsIndex]?.summary || newsList[mainNewsIndex]?.content?.substring(0, 150) + '...'}
                    </p>

                    <div className="flex justify-between items-center pt-4 border-t border-gray-100 mt-auto select-none">
                      <button 
                        onClick={() => handleViewArticle(newsList[mainNewsIndex])}
                        className="bg-[#1a365d] hover:bg-[#0f2544] text-white text-xs font-bold px-4 py-2 rounded-lg transition-colors flex items-center gap-1 shadow-xs"
                      >
                        <span>قراءة التفاصيل بالكامل</span>
                        <span>←</span>
                      </button>

                      {/* Manual Dots / Controls */}
                      <div className="flex items-center gap-1.5">
                        <button 
                          onClick={() => setMainNewsIndex((prev) => (prev - 1 + newsList.length) % newsList.length)}
                          className="p-1.5 hover:bg-slate-100 rounded-lg text-[#1a365d] border border-gray-150 transition-colors"
                          title="الخبر السابق"
                        >
                          <ChevronRight className="w-4 h-4" />
                        </button>
                        
                        <span className="text-[11px] font-mono font-extrabold text-gray-400 px-1">
                          {mainNewsIndex + 1} / {newsList.length}
                        </span>

                        <button 
                          onClick={() => setMainNewsIndex((prev) => (prev + 1) % newsList.length)}
                          className="p-1.5 hover:bg-slate-100 rounded-lg text-[#1a365d] border border-gray-150 transition-colors"
                          title="الخبر التالي"
                        >
                          <ChevronLeft className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>

                </div>
              ) : (
                <div className="p-8 text-center text-gray-400 my-auto">
                  لا يوجد أخبار لعرضها حالياً.
                </div>
              )}
            </div>

            {/* Column 2: Mini News side panel with 10s rotation (4 cols / 1/3 width) */}
            <div className="lg:col-span-4 bg-[#0c1e36] rounded-2xl border border-white/10 p-6 flex flex-col justify-between min-h-[420px] text-right relative overflow-hidden select-none text-white">
              
              {/* Top label */}
              <div className="space-y-1 pb-3 border-b border-white/10">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-red-400 font-extrabold text-xs">
                    <Megaphone className="w-4 h-4 animate-bounce text-red-400" />
                    <span>موجز أخبار اليوم المباشر</span>
                  </span>
                  
                  {/* Countdown indicator circle/badge */}
                  <div className="bg-amber-500 text-white font-mono text-[10px] font-black px-2 py-0.5 rounded-full flex items-center gap-1">
                    <span>تحديث خلال:</span>
                    <span className="w-4 text-center">{countdown}ث</span>
                  </div>
                </div>
                <p className="text-[10px] text-white/60 font-medium">يتغير التوجيه التلقائي للموجز الإخباري المباشر كل 10 ثوانٍ</p>
              </div>

              {/* Displaying active sideNews */}
              {newsList.length > 0 ? (
                <AnimatePresence mode="wait">
                  <motion.div 
                    key={sideNewsIndex}
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.98 }}
                    transition={{ duration: 0.4 }}
                    className="flex-grow flex flex-col justify-between py-6"
                  >
                    <div className="space-y-3">
                      <span className="text-[9px] font-mono text-amber-400 block font-bold">
                        نشرت بتاريخ: [{newsList[sideNewsIndex]?.date}]
                      </span>
                      <h4 
                        onClick={() => handleViewArticle(newsList[sideNewsIndex])}
                        className="text-sm font-bold text-white leading-snug cursor-pointer hover:text-amber-400 hover:underline"
                      >
                        {newsList[sideNewsIndex]?.title}
                      </h4>
                      <p className="text-xs text-white/80 leading-relaxed line-clamp-4 font-semibold">
                        {newsList[sideNewsIndex]?.summary || newsList[sideNewsIndex]?.content?.substring(0, 100) + '...'}
                      </p>
                    </div>

                    <button 
                      onClick={() => handleViewArticle(newsList[sideNewsIndex])}
                      className="text-xs text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1 pt-3 border-t border-white/10 self-start mt-4"
                    >
                      <span>قراءة الخبر الموجز بالكامل</span>
                      <span>←</span>
                    </button>
                  </motion.div>
                </AnimatePresence>
              ) : (
                <div className="text-center text-white/40 py-10 my-auto">
                  لا يوجد موجز لآخر الأخبار.
                </div>
              )}

              {/* Progress bar timeline */}
              <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden mt-auto">
                <motion.div 
                  key={`progress-side-news-${sideNewsIndex}`}
                  initial={{ width: '100%' }}
                  animate={{ width: '0%' }}
                  transition={{ duration: 10, ease: 'linear' }}
                  className="bg-amber-500 h-full"
                ></motion.div>
              </div>

            </div>

          </div>
        </div>
      </section>
    );
  };

  const renderAudiencesSection = () => {
    return (
      <section id="audience-portlets" className="scroll-mt-48 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Citizens */}
          <div className="bg-white p-6 rounded-xl border border-gray-200/50 hover:border-amber-500/40 shadow-sm hover:shadow-md transition-all text-right flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-lg bg-amber-500/10 text-amber-700 flex items-center justify-center mb-4">
                <Building2 className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-gray-800 mb-2">بوابة الأفراد والمواطنين</h4>
              <p className="text-xs text-gray-500 leading-relaxed mb-4">
                تقديم طلبات الفحص لإثبات الاعتداء والجنايات، الاستشارات الطبية الشرعية السريرية والسموم بأحكام قضائية، أو طلبات استلام جثامين ذويهم وتصاريح الدفن.
              </p>
            </div>
            <button 
              onClick={() => setCurrentTab('guide')}
              className="text-[#1a365d] hover:text-amber-500 text-xs font-bold flex items-center gap-1 transition-colors group mt-2"
            >
              <span>تصفح دليل المواطنين</span>
              <ArrowLeft className="w-3.5 h-3.5 transition-transform group-hover:translate-x-[-2px]" />
            </button>
          </div>

          {/* Card 2: Prosecution & Judges */}
          <div className="bg-white p-6 rounded-xl border border-gray-200/50 hover:border-amber-500/40 shadow-sm hover:shadow-md transition-all text-right flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-lg bg-[#1a365d]/5 text-[#1a365d] flex items-center justify-center mb-4">
                <Scale className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-gray-800 mb-2">القضاء وأعضاء النيابة العامة</h4>
              <p className="text-xs text-gray-500 leading-relaxed mb-4">
                منظومة خاصة للنيابات والمحاكم لطلب انتداب الأطباء الشرعيين لندب التشريح، أو حجز استشارات طبية فنية جنائية عاجلة ومحكمة.
              </p>
            </div>
            <button 
              onClick={() => setCurrentTab('contact')}
              className="text-[#1a365d] hover:text-amber-500 text-xs font-bold flex items-center gap-1 transition-colors group mt-2"
            >
              <span>قنوات التواصل والتنسيق القضائي</span>
              <ArrowLeft className="w-3.5 h-3.5 transition-transform group-hover:translate-x-[-2px]" />
            </button>
          </div>

          {/* Card 3: Researchers */}
          <div className="bg-white p-6 rounded-xl border border-gray-200/50 hover:border-amber-500/40 shadow-sm hover:shadow-md transition-all text-right flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center mb-4">
                <GraduationCap className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-gray-800 mb-2">الباحثون وطلاب كليات الطب</h4>
              <p className="text-xs text-gray-500 leading-relaxed mb-4">
                بوابة الباحثين لطلب مادة علمية متخصصة من أرشيف المركز، أو التقديم لحجز برامج تدريب ميداني وعملي بمختبرات وصالات التشريح.
              </p>
            </div>
            <button 
              onClick={() => setCurrentTab('guide')}
              className="text-[#1a365d] hover:text-amber-500 text-xs font-bold flex items-center gap-1 transition-colors group mt-2"
            >
              <span>الاطلاع على شروط التدريب والبحث</span>
              <ArrowLeft className="w-3.5 h-3.5 transition-transform group-hover:translate-x-[-2px]" />
            </button>
          </div>
        </div>
      </section>
    );
  };

  const renderStatsSection = () => {
    return (
      <section id="stats-dashboard" className="scroll-mt-48 bg-white border-y border-gray-200 py-10 sm:py-12 select-none">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8 text-right">
            <h3 className="text-lg sm:text-xl font-bold text-[#1a365d] flex items-center justify-center gap-2">
              <Activity className="w-5 h-5 text-amber-500" />
              <span>حقائق وإحصائيات أعمال المركز الوطني للطب الشرعي</span>
            </h3>
            <p className="text-xs text-gray-400 mt-1">البيانات الإحصائية الرسمية التراكمية للمركز منذ التأسيس والاعتماد بالوزارة</p>
          </div>

          {/* Simple summary boxes */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {stats.map((stat, idx) => (
              <div 
                key={`home-stat-${idx}`} 
                className="p-5 rounded-xl border border-gray-150 text-center hover:border-amber-500/30 transition-all bg-slate-50 shadow-sm text-right"
              >
                <span className="block text-2xl sm:text-3xl font-extrabold text-[#1a365d] font-mono tracking-tight mb-1 text-center">
                  <CountUp value={stat.value} />
                </span>
                <span className="block text-xs font-bold text-gray-800 mb-1">
                  {stat.label}
                </span>
                <span className="block text-[10px] text-gray-400 leading-relaxed">
                  {stat.description}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  };

  const renderChartsSection = () => {
    return (
      <section id="charts-dashboard" className="scroll-mt-48 bg-slate-50 border-y border-gray-200 py-10 sm:py-12 select-none">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-right">
          <div className="text-center mb-6">
            <h4 className="text-base sm:text-lg font-bold text-[#1a365d]">مؤشرات الأداء البيانية التفاعلية</h4>
            <p className="text-xs text-gray-400 mt-0.5">مؤشرات نمو وتوزيع الخدمات والتحاليل الطبية الشرعية لوزارة العدل</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Chart 1: Growth */}
            <div className="bg-white border border-gray-200/70 rounded-2xl p-4 shadow-sm flex flex-col justify-between">
              <div className="text-right mb-3">
                <h5 className="text-xs font-extrabold text-[#1a365d]">منحنى النمو السنوي للخدمات</h5>
                <p className="text-[10px] text-gray-400 mt-0.5">تطور أعداد التقارير والسموم المنجزة سنوياً</p>
              </div>
              <div className="w-full h-[220px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartGrowthData} margin={{ top: 5, right: 5, left: -25, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorCases" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#1a365d" stopOpacity={0.2}/>
                        <stop offset="95%" stopColor="#1a365d" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorTox" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.2}/>
                        <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="year" stroke="#718096" fontSize={10} />
                    <YAxis stroke="#718096" fontSize={10} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend verticalAlign="top" height={24} iconType="circle" wrapperStyle={{ fontSize: 9, fontWeight: 'bold' }} />
                    <Area type="monotone" name="التقارير الطبية الشرعية" dataKey="cases" stroke="#1a365d" strokeWidth={2} fillOpacity={1} fill="url(#colorCases)" />
                    <Area type="monotone" name="فحوصات وتحاليل السموم" dataKey="toxicology" stroke="#f59e0b" strokeWidth={2} fillOpacity={1} fill="url(#colorTox)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 2: Distribution */}
            <div className="bg-white border border-gray-200/70 rounded-2xl p-4 shadow-sm flex flex-col justify-between">
              <div className="text-right mb-3">
                <h5 className="text-xs font-extrabold text-[#1a365d]">توزيع نوعية الخدمات والتقارير</h5>
                <p className="text-[10px] text-gray-400 mt-0.5">النسب المئوية الإحصائية لتصنيف القضايا</p>
              </div>
              <div className="w-full h-[220px] flex flex-col justify-center">
                <div className="h-[120px] w-full flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={chartDistributionData}
                        cx="50%"
                        cy="50%"
                        innerRadius={30}
                        outerRadius={50}
                        paddingAngle={3}
                        dataKey="value"
                      >
                        {chartDistributionData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip content={<CustomPieTooltip />} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-2 space-y-1 pr-1 text-right overflow-y-auto max-h-[90px]">
                  {chartDistributionData.map((item, index) => (
                    <div key={`chart-dist-${index}`} className="flex items-center justify-between border-b border-gray-100/60 pb-1">
                      <span className="text-[9px] font-mono text-[#1a365d] font-bold">({item.value}%)</span>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[9px] font-bold text-gray-700">{item.name}</span>
                        <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: item.color }}></span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Chart 3: Monthly */}
            <div className="bg-white border border-gray-200/70 rounded-2xl p-4 shadow-sm flex flex-col justify-between">
              <div className="text-right mb-3">
                <h5 className="text-xs font-extrabold text-[#1a365d]">النشاط الشهري للمركز (2026)</h5>
                <p className="text-[10px] text-gray-400 mt-0.5">حجم العمل الشهري للتقارير وفحوصات المختبر</p>
              </div>
              <div className="w-full h-[220px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartMonthlyData2026} margin={{ top: 5, right: 5, left: -25, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="month" stroke="#718096" fontSize={10} />
                    <YAxis stroke="#718096" fontSize={10} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend verticalAlign="top" height={24} iconType="circle" wrapperStyle={{ fontSize: 9, fontWeight: 'bold' }} />
                    <Bar name="التقارير الطبية" dataKey="cases" fill="#1a365d" radius={[2, 2, 0, 0]} />
                    <Bar name="فحوصات السموم" dataKey="toxicology" fill="#f59e0b" radius={[2, 2, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Info footer for charts */}
          <div className="mt-4 pt-3 border-t border-gray-200/50 flex flex-col sm:flex-row items-center justify-between text-[10px] text-gray-400 font-medium">
            <span>محدث بانتظام تزامناً مع إيداعات النيابة العامة ووزارة العدل</span>
            <span className="mt-1 sm:mt-0 flex items-center gap-1 text-amber-600 font-bold">
              <Activity className="w-3.5 h-3.5 animate-pulse" />
              <span>المركز الوطني للطب الشرعي - قسم الإحصاء والمعلوماتية</span>
            </span>
          </div>
        </div>
      </section>
    );
  };

  const activeThemeObj = THEMES[themeName] || THEMES.navy;

  return (
    <div className="flex flex-col min-h-screen text-gray-800 bg-slate-50 font-sans antialiased selection:bg-amber-500/30 selection:text-[#1a365d]">
      
      <style>{`
        :root {
          --color-brand-navy: ${activeThemeObj.primary} !important;
          --color-brand-navy-light: ${activeThemeObj.primaryLight} !important;
          --color-brand-gold: ${activeThemeObj.gold} !important;
          --color-brand-gold-light: ${activeThemeObj.goldLight} !important;
        }
      `}</style>
      
      {/* 1. Official Header */}
      <Header key={`header-${settingsVersion}`} currentTab={currentTab} setCurrentTab={setCurrentTab} />

      {/* 2. Scrolling News Ticker */}
      <NewsTicker key={`ticker-${settingsVersion}`} onViewArticle={handleViewArticle} />

      {/* 3. Main Content Wrapper */}
      <main className="flex-grow">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentTab}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.35, ease: 'easeOut' }}
          >
            
            {/* TAB: HOME PAGE */}
            {currentTab === 'home' && (
              <div id="home-view" className="space-y-12">
                
                {/* A. Royal Government Hero Section */}
                <section 
                  id="hero-section"
                  className="scroll-mt-48 relative overflow-hidden text-white py-12 sm:py-16 border-b-4 border-amber-500 select-none bg-[#102544]"
                  style={{
                    backgroundImage: `linear-gradient(to bottom, rgba(16, 37, 68, 0.85), rgba(24, 49, 84, 0.93)), url('/src/assets/images/center_building_1782706794477.jpeg')`,
                    backgroundSize: 'cover',
                    backgroundPosition: 'center',
                  }}
                >
                  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-right">
                    {/* Grand Heading */}
                    <h2 className="text-2xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight leading-tight max-w-5xl">
                      {centerMainTitle}
                    </h2>
                    
                    <div className="mt-4 inline-block bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-lg px-4 py-2 font-bold text-sm sm:text-base lg:text-lg">
                      {centerMainBadge}
                    </div>
                    
                    <p className="mt-4 text-xs sm:text-sm lg:text-base text-white/70 max-w-3xl leading-relaxed font-medium">
                      {centerMainDesc}
                    </p>

                    {/* Call to Actions */}
                    <div className="mt-8 flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
                      <button 
                        onClick={() => setCurrentTab('guide')}
                        className="bg-amber-500 text-white hover:bg-amber-600 font-bold text-xs sm:text-sm px-6 py-3 rounded-lg transition-all shadow-md transform hover:-translate-y-0.5 active:translate-y-0 flex items-center justify-center gap-1.5"
                      >
                        <HelpCircle className="w-4 h-4" />
                        <span>تصفح دليل خدمات المواطن</span>
                      </button>
                      <button 
                        onClick={() => setCurrentTab('about')}
                        className="bg-white/10 hover:bg-white/15 border border-white/20 text-white font-bold text-xs sm:text-sm px-6 py-3 rounded-lg transition-all flex items-center justify-center gap-1"
                      >
                        <span>تعرف على الهيكل والإدارات التخصصية</span>
                        <ArrowLeft className="w-4 h-4 text-amber-400" />
                      </button>
                    </div>

                    {/* Trust indicators */}
                    <div className="mt-10 pt-8 border-t border-white/10 w-full max-w-3xl flex flex-wrap justify-center items-center gap-x-8 gap-y-3 text-xs text-white/50">
                      <span className="flex items-center gap-1.5">
                        <ShieldCheck className="w-4 h-4 text-amber-400" />
                        <span>سرية وخصوصية أمنية مطلقة</span>
                      </span>
                      <span className="hidden sm:inline text-white/10">|</span>
                      <span className="flex items-center gap-1.5">
                        <Landmark className="w-4 h-4 text-amber-400" />
                        <span>بإشراف مباشر من وزارة العدل</span>
                      </span>
                    </div>
                  </div>
                </section>

                {/* Dynamically Ordered Content Sections */}
                {sectionsOrder.map((sectionId) => {
                  if (sectionId === 'news') return <React.Fragment key="news">{renderNewsSection()}</React.Fragment>;
                  if (sectionId === 'audiences') return <React.Fragment key="audiences">{renderAudiencesSection()}</React.Fragment>;
                  if (sectionId === 'stats') return <React.Fragment key="stats">{renderStatsSection()}</React.Fragment>;
                  if (sectionId === 'charts') return <React.Fragment key="charts">{renderChartsSection()}</React.Fragment>;
                  return null;
                })}



                {/* E. Call to Action: Security & Complaint Portal */}
                <section id="complaint-portal" className="scroll-mt-48 bg-slate-100 py-12 border-y border-gray-200 select-none">
                  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="bg-white rounded-2xl border border-gray-200/40 p-6 sm:p-8 shadow-md">
                      <div className="flex flex-col lg:flex-row items-center justify-between gap-6 text-right">
                        <div>
                          <div className="inline-flex items-center gap-1.5 bg-[#1a365d]/5 text-[#1a365d] font-bold text-xs px-3 py-1 rounded-full mb-3 border border-[#1a365d]/10">
                            <ShieldCheck className="w-3.5 h-3.5" />
                            <span>تطوير وإشراف فني أمني</span>
                          </div>
                          <h4 className="text-lg sm:text-xl font-bold text-[#1a365d] mb-1.5">
                            هل تملك استعلاماً قضائياً أو ترغب في تظلم فني؟
                          </h4>
                          <p className="text-xs text-gray-500 max-w-2xl leading-relaxed">
                            يتيح لك دليل المواطن معرفة كافة المستندات المطلوبة والإدارات الرسمية للحصول على التقارير الفنية المعتمدة. كما يتيح لك قسم الشكاوى أو "اتصل بنا" رفع تظلمات فنية مباشرة لرئيس المركز الوطني للطب الشرعي لإعادة الفحص والتدقيق.
                          </p>
                        </div>
                        <div className="flex gap-2 shrink-0">
                          <button 
                            onClick={() => setCurrentTab('guide')}
                            className="bg-[#1a365d] text-white hover:bg-[#0f2544] font-bold text-xs sm:text-sm px-5 py-2.5 rounded-lg transition-colors shadow-sm"
                          >
                            الاطلاع على دليل المواطن
                          </button>
                          <button 
                            onClick={() => setCurrentTab('contact')}
                            className="bg-white hover:bg-gray-50 border border-gray-200 text-gray-700 font-bold text-xs sm:text-sm px-5 py-2.5 rounded-lg transition-colors"
                          >
                            اتصل بقسم المساعدة
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </section>

              </div>
            )}

            {/* TAB: ABOUT PAGE */}
            {currentTab === 'about' && <AboutSection key={`about-${settingsVersion}`} />}

            {/* TAB: CITIZEN GUIDE PAGE */}
            {currentTab === 'guide' && <CitizenGuide />}

            {/* TAB: MEDIA NEWS CENTER PAGE */}
            {currentTab === 'media' && <MediaCenter onViewArticle={handleViewArticle} />}

            {/* TAB: NEWS DETAIL PAGE */}
            {currentTab === 'news-detail' && (
              <NewsDetail 
                article={activeArticle} 
                onBack={() => {
                  setCurrentTab(previousTab || 'media');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                onViewArticle={handleViewArticle}
              />
            )}

            {/* TAB: COMPLAINTS PORTAL PAGE */}
            {currentTab === 'complaints' && <ComplaintsSection />}

            {/* TAB: CONTACT PAGE */}
            {currentTab === 'contact' && <ContactSection />}

            {/* TAB: ADMINISTRATIVE PORTAL */}
            {currentTab === 'admin' && (
              <AdminPanel onSettingsChange={() => setSettingsVersion((prev) => prev + 1)} />
            )}

          </motion.div>
        </AnimatePresence>
      </main>

      {/* 5. Footer */}
      <Footer setCurrentTab={setCurrentTab} />

    </div>
  );
}

// Inline fallback XIcon since lucide-react doesn't have custom X name variations sometimes
function XIcon({ className }: { className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
  );
}

