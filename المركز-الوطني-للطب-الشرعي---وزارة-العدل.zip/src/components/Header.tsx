/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, Search, Landmark, Scale, Shield, Calendar, HelpCircle } from 'lucide-react';

interface HeaderProps {
  key?: React.Key;
  currentTab: string;
  setCurrentTab: (tab: string) => void;
}

export default function Header({ currentTab, setCurrentTab }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  // Dynamic Settings state
  const [govTitle, setGovTitle] = useState('الجمهورية اليمنية');
  const [ministryTitle, setMinistryTitle] = useState('وزارة العدل');
  const [centerTitle, setCenterTitle] = useState('المركز الوطني للطب الشرعي');
  const [centerSubTitle, setCenterSubTitle] = useState('المرجع الوطني المعتمد للخبرة الطبية الشرعية والنفسية والأدلة الجنائية - لدعم تحقيق العدالة');
  const [hotline, setHotline] = useState('774270241');
  const [directPhone, setDirectPhone] = useState('01-445588');

  useEffect(() => {
    // Format current date in Arabic
    const options: Intl.DateTimeFormatOptions = { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    };
    const today = new Date();
    setCurrentTime(today.toLocaleDateString('ar-YE-u-nu-latn', options));
  }, []);

  // Fetch settings from localStorage whenever tab changes or on mount
  useEffect(() => {
    const savedGov = localStorage.getItem('setting_gov') || 'الجمهورية اليمنية';
    const savedMin = localStorage.getItem('setting_ministry') || 'وزارة العدل';
    const savedCenter = localStorage.getItem('setting_center_title') || 'المركز الوطني للطب الشرعي';
    let savedSubCenter = localStorage.getItem('setting_center_subtitle') || 'المرجع الوطني المعتمد للخبرة الطبية الشرعية والنفسية والأدلة الجنائية - لدعم تحقيق العدالة';
    
    // Automatically migrate old subtitle to the new one
    if (savedSubCenter === 'الهيئة الفنية العليا المعتمدة للعدالة والخبرة الطبية الجنائية - وزارة العدل') {
      savedSubCenter = 'المرجع الوطني المعتمد للخبرة الطبية الشرعية والنفسية والأدلة الجنائية - لدعم تحقيق العدالة';
      localStorage.setItem('setting_center_subtitle', savedSubCenter);
    }

    let savedHotline = localStorage.getItem('setting_hotline') || '774270241';
    if (savedHotline === '199') {
      savedHotline = '774270241';
      localStorage.setItem('setting_hotline', savedHotline);
    }

    const savedPhone = localStorage.getItem('setting_phone') || '01-445588';

    setGovTitle(savedGov);
    setMinistryTitle(savedMin);
    setCenterTitle(savedCenter);
    setCenterSubTitle(savedSubCenter);
    setHotline(savedHotline);
    setDirectPhone(savedPhone);
  }, [currentTab]);

  const menuItems = [
    { id: 'home', label: 'الرئيسية' },
    { id: 'about', label: 'عن المركز' },
    { id: 'guide', label: 'دليل المواطن' },
    { id: 'media', label: 'المركز الإعلامي' },
    { id: 'complaints', label: 'الشكاوى والجودة' },
    { id: 'contact', label: 'اتصل بنا' },
    { id: 'admin', label: 'بوابة الموظفين' }
  ];

  const handleTabChange = (tabId: string) => {
    setCurrentTab(tabId);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header id="main-header" className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm">
      {/* Top Bar (Governmental Hierarchy & Time) */}
      <div className="bg-brand-navy text-white border-b border-white/10 text-xs py-2 select-none">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row justify-between items-center gap-2">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1 font-semibold text-white">
              <Landmark className="w-3.5 h-3.5 text-brand-gold" />
              <span>{govTitle}</span>
            </span>
            <span className="text-white/30">|</span>
            <span className="flex items-center gap-1 text-white/80 font-medium">
              <Scale className="w-3.5 h-3.5 text-brand-gold" />
              <span>{ministryTitle}</span>
            </span>
          </div>

          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5 text-white/75 font-medium">
              <Calendar className="w-3.5 h-3.5 text-brand-gold" />
              <span>{currentTime || 'الأحد، 28 يونيو 2026'}</span>
            </span>
            <span className="hidden md:inline text-white/30">|</span>
            <a 
              href={`tel:${hotline}`} 
              className="hidden md:flex items-center gap-1 text-white font-semibold hover:text-brand-gold transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-brand-gold" />
              <span>الرقم الموحد المباشر: {hotline}</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Banner (Emblem, Title and Organization Info) */}
      <div className="py-4 bg-gradient-to-l from-white via-slate-50 to-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Logo / Crest Area */}
          <div className="flex items-center gap-4 text-center md:text-right">
            {/* Republic Coat of Arms Image */}
            <div className="w-40 sm:w-48 h-22 sm:h-28 bg-transparent flex items-center justify-center overflow-hidden">
              <img 
                src="/src/assets/images/center_logo_1782706780996.jpg" 
                alt="شعار المركز" 
                className="w-full h-full object-contain mix-blend-multiply filter contrast-130 brightness-105 transition-transform duration-300 hover:scale-105"
                referrerPolicy="no-referrer"
              />
            </div>
            
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-brand-navy tracking-tight leading-tight">
                {centerTitle}
              </h1>
              <p className="text-xs sm:text-sm text-gray-500 font-medium mt-0.5">
                {centerSubTitle}
              </p>
            </div>
          </div>

          {/* Quick Stats/Contact Widget */}
          <div className="flex items-center gap-3 sm:gap-4">
            
            {/* Search Widget (Simulated) */}
            <div className="hidden lg:flex items-center relative">
              <input
                type="text"
                placeholder="ابحث عن خبر أو خدمة..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-gray-100 hover:bg-gray-200/70 focus:bg-white text-xs text-gray-800 placeholder-gray-400 rounded-lg pr-8 pl-3 py-2 w-48 focus:w-64 transition-all duration-300 border border-transparent focus:border-gray-300 outline-none"
              />
              <Search className="w-4 h-4 text-gray-400 absolute right-2.5 pointer-events-none" />
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Menu */}
      <div className="bg-brand-red text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-12">
            
            {/* Desktop Menu */}
            <nav className="hidden md:flex items-center gap-1 h-full">
              {menuItems.map((item) => {
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleTabChange(item.id)}
                    className={`px-3 lg:px-4 h-full text-xs lg:text-sm font-semibold transition-all relative flex items-center gap-1.5 hover:bg-white/5 ${
                      isActive 
                        ? 'text-brand-gold font-bold bg-white/10' 
                        : 'text-white/80 hover:text-white'
                    }`}
                  >
                    <span>{item.label}</span>
                    {isActive && (
                      <span className="absolute bottom-0 left-0 right-0 h-1 bg-brand-gold"></span>
                    )}
                  </button>
                );
              })}
            </nav>

            {/* Support Portal Link (Guide shortcut) */}
            <div className="hidden md:flex items-center gap-2">
              <button
                onClick={() => handleTabChange('guide')}
                className="bg-brand-navy hover:bg-brand-navy-light text-brand-gold border border-brand-gold/20 text-xs font-bold px-3.5 py-1.5 rounded-md flex items-center gap-1.5 transition-all shadow-sm"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>بوابة دليل المواطن</span>
              </button>
            </div>

            {/* Mobile Menu Toggle Button */}
            <div className="flex md:hidden w-full justify-between items-center">
              <span className="text-xs font-bold text-brand-gold uppercase tracking-wide">
                {menuItems.find(item => item.id === currentTab)?.label}
              </span>
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-1.5 rounded-md hover:bg-white/10 transition-colors text-white"
                aria-label="قائمة التنقل"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>

          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-brand-navy border-t border-brand-red/40 text-white animate-fade-in py-2">
          <div className="px-2 pt-1 pb-3 space-y-1">
            {menuItems.map((item) => {
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleTabChange(item.id)}
                  className={`block w-full text-right px-4 py-2.5 rounded-md text-sm font-semibold transition-colors ${
                    isActive 
                      ? 'bg-brand-red text-brand-gold font-bold' 
                      : 'text-white/80 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
            
            <div className="pt-2 px-4 border-t border-white/10 mt-2">
              <button
                onClick={() => handleTabChange('guide')}
                className="w-full bg-brand-red text-brand-gold font-bold text-center py-2 rounded-md text-sm block"
              >
                الاطلاع على دليل المواطن
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
